# CardTrader CT0 API

Scraper con Puppeteer Core y Chromium del sistema.

## Endpoint

```
/precioCT0?carta=Nombre&expansion=Expansión
```

Devuelve:

```json
{
  "carta": "Carrot Cake",
  "expansion": "Bloomburrow",
  "precio": "1.25"
}
```